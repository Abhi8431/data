package com.example.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final String dbName = "Users";
    private static final String tbName = "user_details";
    private static final int version = 1;


    public DBHelper(@Nullable Context context) {
        super(context, dbName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create the table
        db.execSQL("CREATE TABLE " + tbName + "(uname VARCHAR(30), upass VARCHAR(30))" + ";");
    }

    public long insertUser(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("uname", username);
        cv.put("upass", password);
        long result = db.insert(tbName, null, cv);
        db.close();
        return result;
    }

    public void updateUser(String username, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.execSQL("UPDATE " + tbName + " SET upass='" + password + "' WHERE uname='" + username +"';");
        sqLiteDatabase.close();
    }

    public String displayUsers(){
        String res = "";
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM " + tbName, null);
        while (cursor.moveToNext()){
            res += "Username: " + cursor.getString(0) + " :: Password: " + cursor.getString(1) + "\n";
        }

        return res;
    }

    public void  deleteUser(String username){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.execSQL("DELETE FROM " + tbName + " WHERE uname = '" + username +"';");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
