package com.example.database;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button add, update, del, display;
    TextView result;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = findViewById(R.id.add);
        update = findViewById(R.id.update);
        del = findViewById(R.id.delete);
        display = findViewById(R.id.display);
        result = findViewById(R.id.result);

        dbHelper = new DBHelper(MainActivity.this);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = findViewById(R.id.username);
                password = findViewById(R.id.password);
                String uname, pass;
                uname = username.getText().toString();
                pass = password.getText().toString();
                long res = dbHelper.insertUser(uname, pass);
                if(res <= 0){
                    Toast.makeText(MainActivity.this, "Error! Could not add new user", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Added new user.", Toast.LENGTH_SHORT).show();
                    username.setText("");
                    password.setText("");
                }
            }
        });

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String res = dbHelper.displayUsers();
                result.setText(res);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = findViewById(R.id.username);
                password = findViewById(R.id.password);
                String uname, pass;
                uname = username.getText().toString();
                pass = password.getText().toString();
                dbHelper.updateUser(uname, pass);
                Toast.makeText(MainActivity.this, "Updated user details.", Toast.LENGTH_SHORT).show();
                username.setText("");
                password.setText("");
            }
        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = findViewById(R.id.username);

                String uname;
                uname = username.getText().toString();
                dbHelper.deleteUser(uname);
                String msg = "Deleted " + uname + " from the database";
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                username.setText("");
                password.setText("");
            }
        });
    }
}